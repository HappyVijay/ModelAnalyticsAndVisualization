//var columnheaders = []
function clearForm() {
    document.getElementById("form").reset();
}

var columnheaders=[] 

b = {}
var AID = 0
function func(t) {
    var id = t.id;
    /*
    $.ajax({
        url: "/get_preselected_columns",
        type: "POST",
        data: JSON.stringify(id),
        success: function (data) {
            if(data['score']){
                $('#dropdownScoreButton').text(data['score']);
                $('#dropdownOutcomeButton').text(data['status']);
                $('#dropdownhasAlertButton').text(data['alert']);
                $('#dropdownhasBusinessActionButton').text(data['businessaction']);
                $('#dropdownhasEscalationButton').text(data['escalations'])
            }
        }
    });*/

    $.ajax({
        url: "/get_column_header",
        type: "POST",
        data: JSON.stringify(id),
        success: function (data) {

            console.log(data)

            if(data['score']){
                $('#dropdownScoreButton').text(data['score']);
                $('#dropdownOutcomeButton').text(data['status']);
                $('#dropdownhasAlertButton').text(data['alert_flag']);
                $('#dropdownhasBusinessActionButton').text(data['businessAction']);
                $('#dropdownhasEscalationButton').text(data['escalation_flag'])
            
            }



            columnheaders = data['data'];
            console.log(columnheaders);
            $('.dropdown-menu1').empty()
            $('.dropdown-menu2').empty()
            $('.dropdown-menu3').empty()
            $('.dropdown-menu4').empty()
            $('.dropdown-menu5').empty()
           
            $("#checkboxtable").dataTable().fnDestroy();
            $("#checkboxtable1").empty();


            count=0
            $.each(columnheaders, function (index, value) {
                //console.log(value);
                count++;
                if (index <= 5){
                    b[value] = true
                    $('#checkboxtable1').append('<tr class="form-check"> <td> <input name = "featurecheckbox"  id=' + value + ' class="form-check-input" type="checkbox" onclick="addme(this)"  checked><label class="form-check-label" >' + value + '</label></td></tr>');
                }else{
                    $('#checkboxtable1').append('<tr class="form-check"> <td> <input name = "featurecheckbox"  id=' + value + ' class="form-check-input" type="checkbox" onclick="addme(this)" ><label class="form-check-label">' + value + '</label></td></tr>');
                    b[value] = false
                }
                $('.dropdown-menu1').each(function (index, element) {
                    
                    $(this).append('<a class="dropdown-item dropdown-item1" >' + value + '</a>');
                })
                $('.dropdown-menu2').each(function (index, element) {
                    //console.log(element);
                    $(this).append('<a class="dropdown-item dropdown-item2" >' + value + '</a>');
                })
                $('.dropdown-menu3').each(function (index, element) {
                    //console.log(element);
                    $(this).append('<a class="dropdown-item dropdown-item3" >' + value + '</a>');
                })
                $('.dropdown-menu4').each(function (index, element) {
                    //console.log(element);

                    $(this).append('<a class="dropdown-item dropdown-item4">' + value + '</a>');
                })
                $('.dropdown-menu5').each(function (index, element) {
                    //console.log(element);
                    $(this).append('<a class="dropdown-item dropdown-item5">' + value + '</a>');
                })

            });

            
            $('#checkboxtable').DataTable({
                "ordering": false,
                "paging": true,
                "lengthMenu": [5, 10],
                "lengthChange": false,
                "searching": false

            });



            var table = document.getElementById("myTable");
            rows = document.getElementsByClassName("clickme");

            count = 0;
            $('#dropdownScoreButton').click(function () {

                $(this).css("width", "fit-content")
                $('.dropdown-item1').each(function (i, v) {
                    $(v).click(function (e) {
                        e.preventDefault();
                        $('#dropdownScoreButton').text($(v).text());
                        count++;
                        $('#l1').show();

                    });

                })

            })

            $('#dropdownOutcomeButton').click(function () {

                $(this).css("width", "fit-content")
                $('.dropdown-item2').each(function (i, v) {
                    $(v).click(function (e) {
                        e.preventDefault();
                        $('#dropdownOutcomeButton').text($(v).text());
                        count++;
                        $('#l2').show();
                    });
                })
            })

            $('#dropdownhasAlertButton').click(function () {
                $(this).css("width", "fit-content")
                $('.dropdown-item3').each(function (i, v) {
                    $(v).click(function (e) {
                        e.preventDefault();
                        $('#dropdownhasAlertButton').text($(v).text());
                        count++;
                        $('#l3').show();
                    });
                })
            })

            $('#dropdownhasBusinessActionButton').click(function () {
                $(this).css("width", "fit-content")
                $('.dropdown-item4').each(function (i, v) {
                    $(v).click(function (e) {
                        e.preventDefault();
                        $('#dropdownhasBusinessActionButton').text($(v).text());
                        count++;
                        $('#l4').show();
                    });
                })
            })

            $('#dropdownhasEscalationButton').click(function () {
                $(this).css("width", "fit-content")
                $('.dropdown-item5').each(function (i, v) {
                    $(v).click(function (e) {
                        e.preventDefault();
                        $('#dropdownhasEscalationButton').text($(v).text());
                        count++;
                        $('#l5').show();
                    });
                })
            })


            if(data['score']){
               
                $.each(data['data'], function (index, value) {
                    
                    $.each(data['features'], function (i, v) {
                        if(value == v) {
                            console.log("hll")
                                console.log($('#'+ value).prop("checked"));
                        }  


                    })
                })


            }


            clearForm()


            $(rows)
                .attr("data-toggle", "modal")
                .attr("data-target", "#mymodel");

        



           // console.log(data)
           // console.log(t.id)
        }
    });
}

function deletemodel(t) {
    var id = t.id - 1;
    
        $.ajax({
            url: "/deleteModel",
            type: "POST",
            data: JSON.stringify(id),
            success: function (data) {
                console.log("done")
            }
        });
    
}




function addme(t) {
   // console.log(t.id)
    if($(t).prop("checked")){
        b[t.id] = true
    }
    else{
        b[t.id] = false
    }

    
}








$('#save').click(function() {
    console.log("Hello")
    //For the grand 5 columns
    a = {};
    a['score'] = $('#dropdownScoreButton').text();
    a['outcome'] =  $('#dropdownOutcomeButton').text();
    a['alert'] = $('#dropdownhasAlertButton').text();
    a['businessaction'] = $('#dropdownhasBusinessActionButton').text();
    a['escalation'] = $('#dropdownhasEscalationButton').text();  

    // For the great features
   
    console.log(a);
    console.log(b);
    
    var c = { a1: a, b1: b };
      $.ajax({
        url: "/send_data",
        type: "POST",
        data: JSON.stringify(c),
        success: function (data) {
                      
        }
    });
    //$("#proceed").prop("aria-disabled", false) 
    $("#proceed").removeClass("disabled")
});	


function getCountOfFeatures()  {
    no = 0
    $.each( b, function( key, value ) {
        
        if (value)
            no++;

      });
    return no;

}


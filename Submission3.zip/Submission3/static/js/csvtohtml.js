/**
 * 
 * This is used to convert the given csv file into html
 */

$(document).ready(function(){
    var id = $('#getcount').html()
   $.ajax({
       url:"static/" + id + "/temp/data50.csv",
       dataType:"text",
       success:function(data)
       {
        var employee_data = data.split(/\r?\n|\r/);
        var table_data = '<table class="table table-bordered table-striped" id = "mytable">';
        for(var count = 0; count<employee_data.length - 1; count++)
        {
         var cell_data = employee_data[count].split(",");
         if (count == 0){
             table_data += '<thead>';
         }
         if (count == 1){
             table_data += '<tbody>';
         }
         table_data += '<tr>';
         for(var cell_count=0; cell_count<cell_data.length; cell_count++)
         {
          if(count === 0)
          {
           table_data += '<th>'+cell_data[cell_count]+'</th>';
          }
          else
          {
           table_data += '<td>'+cell_data[cell_count]+'</td>';
          }
         }

         table_data += '</tr>';
         if (count == 0) {
             table_data += '</thead>';
         }
         if (count == employee_data.length - 2) {
             table_data += '</tbody>';
         } 
        }
        table_data += '</table>';
        $('#container').html(table_data);
        $('#mytable').dataTable();
    
    }
      });
         });

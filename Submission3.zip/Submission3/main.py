import math
import os
from datetime import datetime
from flask import Flask, render_template, request, session, redirect, jsonify
from stats import *
from werkzeug.utils import secure_filename
import json
import pandas as pd
import sqlite3

cutoff = 40                             #so that the page doesn't look empty at start
id = 0                                  #global Id for all pages, that uniquely identifies the model
modelName = ""                          #model name, later will have same name that user selected                       
app = Flask(__name__)
app.secret_key = 'super-secret-key'

# This will route the Landing page of the dashboard
@app.route('/', methods = ['POST', 'GET'])
def Home():
    global id
    global app
    global modelName
    
    if request.method == 'POST':
        #fetch details from the form
        Model_name = request.form["Model_name"]
        Model_Description = request.form["Model_Desc"]
        Created_by = "User"
        f = request.files['myfile']       
        file = f.filename
        date = datetime.now()
        modelName = Model_name
        #query to insert into database
        id = insertdata(Model_name, Model_Description, Created_by, file, date)
        name = "static/"+str(id)+"/"+f.filename
        updatefile(name,id) 
        UPLOAD_FOLDER = os.getcwd() +"/static/"+str(id) +"/"
        app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
        path = "static/"+str(id)+"/"
        f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename))
        return render_template("home.html", rows=get_all_rows())
        #return home.html
    return render_template("home.html", rows=get_all_rows() )
    

#get the column headers through post request for auto-fill feature
@app.route('/get_column_header', methods=['POST', 'GET'])
def get_columns():
    global id
    global modelName
    received_data = request.get_json(force=True)
    id = int(received_data)
    print(type(id))
    modelName = getModelName(id)
    print(modelName)
    data = get_column_header(id)
    data = list(data)
    features, score ,status ,alert_flag ,bunessAction,escalation_flag =popup_data(id)
    print(data)

    d = {'data' : data, 'features' :features,'score':score, 'status': status,'alert_flag' : alert_flag, 'businessAction' : bunessAction,'escalation_flag' : escalation_flag}
    d = jsonify(d)
    return d

#The Dashboard
@app.route('/dashboard')
def dashpage():
    global id
    global modelName
    imp_alert = feature_imp(id, 1)
    data1 = {}
    data1['alerts'] = []
    for i in imp_alert:
        a, b = i
        d = {}
        d["features"] = a
        d["importances"] = round(b*100,3)
        data1['alerts'].append(d)
    imp_esc = feature_imp(id, 0)
    data1['escalations'] = []
    for i in imp_esc:
        a, b = i
        d = {}
        d["features"] = a
        d["importances"] = round(b*100,3)
        data1['escalations'].append(d)
    
    print(data)
    Pear_values, f1 = correlation_mat(id,1)
    Spear_values, f2 = correlation_mat(id, 0)
    data2 = {}
    data2['Pearson'] = []
    i = 0
    j = 0
    for f in f1:
        for f3 in f2:
            d = {}
            d['group'] = f
            d['variable'] = f3
            d['value'] = Pear_values[i][j]
            data2['Pearson'].append(d)
            j=j+1
        i += 1
        j = 0

    data2['Spearman'] = []
    k = 0
    l = 0
    for f in f1:
        for f3 in f2:
            d = {}
            d['group'] = f
            d['variable'] = f3
            d['value'] = Spear_values[k][l]
            data2['Spearman'].append(d)
            l=l+1
        k += 1
        l = 0  
    alert = statistics_of_all_feature(id,1)
    nonalert = statistics_of_all_feature(id,2)
    escalation = statistics_of_all_feature(id,3)
    alert = alert.replace("\n", "\\n")
    nonalert = nonalert.replace("\n", "\\n")
    escalation = escalation.replace("\n", "\\n")
    total_cases_surv,alert_per_surv,nonalert_per_surv,escalations_per_surv = common_calculations(id)

    box_data=boxdata(id)
    violin_data=violindata(id)

    return render_template('dashboard.html', id = id, modelname = modelName, data1 = data1,data2 = data2,alert=alert, nonalert = nonalert, escalation=escalation,total_case = total_cases_surv, alert_per_surv = alert_per_surv,nonalert_per_surv=nonalert_per_surv,escalations_per_surv= escalations_per_surv,box_data=box_data,violin_data=violin_data)


#Extract data from the popUp and the front-end sends it to back-end
@app.route('/send_data', methods=['POST', 'GET'])
def update():
    global id
    global modelName
    if request.method == 'POST':
        received = request.get_json(force=True)
        a = received["a1"]
        b = received["b1"]
        score = a["score"]
        outcome = a["outcome"]
        alert = a["alert"]
        business_action = a["businessaction"]
        escalation = a["escalation"]
        features = ""
        cols = get_column_header(id)
        for col in cols:
            if b[col] == True:
                features += col + ","
        print(features)
        updatedata(features, score, outcome, alert, business_action, escalation, id)
        print(get_all_rows())
        cutofffinal(id)
        return "successful"
    return "unsuccessful"


#render the visualizations page for feature distribution
@app.route('/visualizations')
def Visualizations():
    global id
    global modelName
    c = get_feature_count(id)
    #we need to pass model name since its in all the pages of navbar
    return render_template('boxplot.html', count=c, modelname = modelName)


#render the strip plot page
@app.route('/stripplot')
def stripplot():
    global id
    global modelName
    c = get_feature_count(id)
    #we need to pass model name since its in all the pages of navbar
    return render_template('strip.html', count=c, modelname = modelName)

#render the violin and box plot page
@app.route('/violinboxplot')
def violinbox():
    global id
    global modelName
    c = get_feature_count(id)
    return render_template('violinandboxplot.html', count=c, modelname = modelName)

#to show the data in CSV file in form of more readable table
@app.route('/data', methods=['GET', 'POST'])
def Data():
    global id
    global modelName
    datatoshow(id)
    return render_template('data.html', id=id, modelname = modelName)

#The FAQ Page
@app.route('/faq')
def Faq():
    global modelName
    return render_template('faq.html', modelname = modelName)

#The About Us Page
@app.route('/aboutUs')
def AboutUs():
    global modelName
    return render_template('aboutus.html', modelname = modelName)

#The summary statistics page
@app.route('/summarystatistics')
def SummaryStatistics():
    global id
    global modelName
    #flag =1 is for alerted
    #flag =2 is for non-alerted
    #flag = 3 is for escalations
    #n amodelName = getModelName(id)
    #The files containing relevant data are created 
    alert = statistics_of_all_feature(id,1)
    nonalert = statistics_of_all_feature(id,2)
    escalation = statistics_of_all_feature(id,3)
    alert = alert.replace("\n", "\\n")
    nonalert = nonalert.replace("\n", "\\n")
    escalation = escalation.replace("\n", "\\n")
    total_cases_surv,alert_per_surv,nonalert_per_surv,escalations_per_surv = common_calculations(id)
    
    #file name static/js/statistics_of_alert_featurenew.csv
    return render_template('summary.html',alert=alert, nonalert = nonalert, escalation=escalation  , id=id, modelname = modelName,  total_case = total_cases_surv, alert_per_surv = alert_per_surv,nonalert_per_surv=nonalert_per_surv,escalations_per_surv= escalations_per_surv)

#The feature importance page
@app.route('/featureimp',  methods=['GET', 'POST'])
def featureimp():
    global id
    global modelName
    #### id is static for now need to change afterwards to make dashboard generic
    # feature_imp(id,0, "static/" + str(id) + "/temp/feature_imp_escalations.csv")
    # feature_imp(id,1, "static/" + str(id) + "/temp/feature_imp_alert.csv")
    # return render_template('featureimp.html', id = id, modelname = modelName)
    imp_alert = feature_imp(id, 1)
    data = {}
    data['alerts'] = []
    for i in imp_alert:
        a, b = i
        d = {}
        d["features"] = a
        d["importances"] = round(b*100,3)
        data['alerts'].append(d)
    imp_esc = feature_imp(id, 0)
    data['escalations'] = []
    for i in imp_esc:
        a, b = i
        d = {}
        d["features"] = a
        d["importances"] = round(b*100,3)
        data['escalations'].append(d)
    print(data)   
    return render_template('featureimp.html', id = id, modelname = modelName, data = data)

#The correlation matrix
@app.route('/cfmatrix')
def cfmatrix():
    global id
    global modelName
    #### id is static for now need to change afterwards to make dashboard generic
    Pear_values, f1 = correlation_mat(id,1)
    Spear_values, f2 = correlation_mat(id, 0)
    data = {}
    data['Pearson'] = []
    i = 0
    j = 0
    for f in f1:
        for f3 in f2:
            d = {}
            d['group'] = f
            d['variable'] = f3
            d['value'] = Pear_values[i][j]
            data['Pearson'].append(d)
            j=j+1
        i += 1
        j = 0

    data['Spearman'] = []
    k = 0
    l = 0
    for f in f1:
        for f3 in f2:
            d = {}
            d['group'] = f
            d['variable'] = f3
            d['value'] = Spear_values[k][l]
            data['Spearman'].append(d)
            l=l+1
        k += 1
        l = 0
    

    return render_template('correlationmx.html', modelname = modelName, id=id, data = data)

#The confusion matrix page
@app.route('/confusionmatrix')
def confmatrix():
    global id
    global modelName
    tp,fp,fn,tn,accuracy,precision,recall = confusion_metrix(id)
    return render_template('confusionmatrix.html',tp = tp,fp = fp,fn = fn,tn = tn,accuracy = accuracy,precision = precision,recall = recall, modelname = modelName)

#The business Review Page
@app.route('/businessaction',  methods=['GET', 'POST'])
def businessaction():
    global id
    global modelName
    boxdata = business_review_boxplot(id)
    stripdata = violin_business_review(id)
    reviews = alerts_per_business_review(id)
    review_name = []
    data = {}
    data['data'] = []

    for r in reviews:
        review_name.append(r[0])
        d = {}
        a, b = r
        d['review'] = a
        d['frequency'] = b
        data['data'].append(d)
    
    review = {}
    review['Rev'] = review_name
    review_count = len(reviews)
    
    print(review_name)
    return render_template('BusinessReview.html', boxdata=boxdata,id=id, reviews = json.dumps(review) ,stripdata = stripdata,review_count =review_count, modelname = modelName, data=data)



#get Data required for Visualizations
####################################################################################################################################
@app.route("/get_data", methods=['POST', 'GET'])
def data():
    global id
    global modelName
    received_data = request.get_json(force=True)
    a = received_data["a"]
    b = received_data["b"]
    
    model_data = get_data_by_id(id)
    file = model_data[4]
    features=feature_list(model_data[6])
    df = pd.read_csv(file)
    alert_flag = model_data[9]
    escalation_flag= model_data[11]
    column = get_column_header(id)
    feature_count = get_feature_count(id)
    new_columns = []
    if b['f0'] == True:
        j = 0
        for k in range(0, len(b) - 1):
            new_columns.append(features[j])
        j = j + 1
    else:
        for i in range(1, feature_count + 1):
            name = "f" + str(i) 
            if b[name] == True:
                new_columns.append(features[i-1])

    df_alerts = df[df[alert_flag] == 1]
    df_nonalerts = df[df[alert_flag] == 0]
    df_escalations = df[df[escalation_flag] == 1]
    result = {}
    if a['all'] == True:
        for column in new_columns:
            result[column]['non-alerts'] = (list(df_nonalerts[column]))
            result[column]['alerts'] = (list(df_alerts[column]))
            result[column]['escalations'] = (list(df_escalations[column]))

    else:
        for column in new_columns:
            result[column] = {}
            for keys in a:
                if a[keys] == True:
                    if keys == 'non-alert':
                        result[column]['non-alerts'] = (list(df_nonalerts[column]))
                    if keys == 'alert':
                        result[column]['alerts'] = (list(df_alerts[column]))
                    if keys == 'escalations':
                        result[column]['escalations'] = (list(df_escalations[column]))
                    
                else:
                    if keys == 'All':
                        continue
                    else:
                        if keys == 'non-alert':
                            result[column]['non-alerts'] = []
                        if keys == 'alert':
                            result[column]['alerts'] = []
                        if keys == 'escalations':
                            result[column]['escalations'] = []


    return jsonify(result)


@app.route("/generate_data_for_cutoff", methods=['POST', 'GET'])
def cutoffdata():
    global id
    global modelName
    received_data = request.get_json(force=True)
    a = received_data["a"]
    b = received_data["b"]
    
    model_data = get_data_by_id(id)
    file = model_data[4]
    features=feature_list(model_data[6])

    arr = file.split(".")
    arr = arr[0].split("/")
    filename  = "static/"+str(id)+"/temp/" + arr[-1] +"cutoff.csv"
    print(filename)
    df = pd.read_csv(filename)
    alert_flag = model_data[9]
    escalation_flag= model_data[11]
    column = get_column_header(id)
    feature_count = get_feature_count(id)
    new_columns = []
    if b['f0'] == True:
        j = 0
        for k in range(0, len(b) - 1):
            new_columns.append(features[j])
        j = j + 1
    else:
        for i in range(1, feature_count + 1):
            name = "f" + str(i) 
            if b[name] == True:
                new_columns.append(features[i-1])

    df_alerts = df[df[alert_flag] == 1]
    df_nonalerts = df[df[alert_flag] == 0]
    df_escalations = df[df[escalation_flag] == 1]
    result = {}
    if a['all'] == True:
        for column in new_columns:
            result[column]['non-alerts'] = (list(df_nonalerts[column]))
            result[column]['alerts'] = (list(df_alerts[column]))
            result[column]['escalations'] = (list(df_escalations[column]))

    else:
        for column in new_columns:
            result[column] = {}
            for keys in a:
                if a[keys] == True:
                    if keys == 'non-alert':
                        result[column]['non-alerts'] = (list(df_nonalerts[column]))
                    if keys == 'alert':
                        result[column]['alerts'] = (list(df_alerts[column]))
                    if keys == 'escalations':
                        result[column]['escalations'] = (list(df_escalations[column]))
                    
                else:
                    if keys == 'All':
                        continue
                    else:
                        if keys == 'non-alert':
                            result[column]['non-alerts'] = []
                        if keys == 'alert':
                            result[column]['alerts'] = []
                        if keys == 'escalations':
                            result[column]['escalations'] = []


    return jsonify(result)

##################################################################    For Cutoffs ###################################################

@app.route('/cutoff_box_plot')
def cutoffboxplot():
    global id
    global modelName
    c = get_feature_count(id)
    return render_template('cutoff_box_plot.html', count=c, modelname = modelName, id=id)

@app.route('/cutoff_boxandviolin')
def cutoffboxandviolinplot():
    global id
    global modelName
    c = get_feature_count(id)
    return render_template('cutoff_boxandviolin.html', count=c, modelname = modelName, id=id)

@app.route('/cutoff_strip')
def cutoffstripplot():
    global id
    global modelName
    c = get_feature_count(id)
    return render_template('cutoff_strip.html', count=c, modelname = modelName, id=id)

@app.route('/cutoffsummary')
def cutoffsummary():
    global id
    global cutoff
    global modelName
    
    alertsdata,nonalertsdata,escsdata,al, non,esc = cutofffile(id,cutoff)
   # cutofffile(id,cutoff)
    print(alertsdata)
    c = get_feature_count(id)
    return render_template('cutoffsummary.html', count=c, id=id, modelname = modelName, alertsdata=alertsdata,nonalertsdata= nonalertsdata,escsdata=escsdata)


#####################################################################################################################################3

@app.route("/generate_files_for_cutoff", methods=['POST', 'GET'])
def generate_files_for_cutoff():
    global id
    global cutoff
    received_data = request.get_json(force=True)    
    cutoff = int(received_data)
    print(cutoff)
    cutofffile(id,cutoff)
    return "Success"

@app.route("/generate_statistics_for_cutoff_alerts", methods=['POST', 'GET'])
def generate_statistics_for_cutoff_a():
    global id
    global cutoff
    received_data = request.get_json(force=True)
    
    cutoff = int(received_data)
    print(cutoff)
    alertsdata,nonalertsdata,escsdata,al, non,esc = cutofffile(id,cutoff)
    d = {'alerts' : alertsdata}
    return jsonify(d)

@app.route("/generate_statistics_for_cutoff_nonalerts", methods=['POST', 'GET'])
def generate_statistics_for_cutoff_n():
    global id
    global cutoff
    received_data = request.get_json(force=True)
    
    cutoff = int(received_data)
    print(cutoff)
    alertsdata,nonalertsdata,escsdata,al, non,esc = cutofffile(id,cutoff)
    d = {'non-alerts' : nonalertsdata}
    return jsonify(d)

@app.route("/generate_statistics_for_cutoff_esc", methods=['POST', 'GET'])
def generate_statistics_for_cutoff_esc():
    global id
    global cutoff
    received_data = request.get_json(force=True)
    
    cutoff = int(received_data)
    print(cutoff)
    alertsdata,nonalertsdata,escsdata,al, non,esc = cutofffile(id,cutoff)
    d = {'escalations' : escsdata}
    return jsonify(d)



##########################################################################################################################################

@app.route('/deleteModel',  methods=['GET', 'POST'])
def deleteModel():
    global modelName
    id =  request.get_json(force=True)
    id = int(id)
    delete_model(id)
    return "Success"









app.run(debug=True)
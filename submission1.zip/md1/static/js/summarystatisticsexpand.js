$('.summarystatistics').hide();

$('#myid1').hover(function () {
        $('.summarystatistics')
        .show();
        console.log('Hello');        

    }, function () {
        
        
        console.log('Bye');
    }
);